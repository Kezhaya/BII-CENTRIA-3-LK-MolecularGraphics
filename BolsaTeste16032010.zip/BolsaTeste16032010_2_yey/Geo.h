/*
 * Geo.h
 *
 *  Created on: 2009/10/10
 *      Author: Jojoma
 */

#include <string> //por causa das strings
#include <Ogre.h> //por causa do ManualObject

using namespace Ogre;

//////////////////////////////////////////////////////////////////////////
// abstract class Geo with only pure (virtual) functions
//////////////////////////////////////////////////////////////////////////
class Geo {
	public:
		virtual ManualObject* getObject() = 0;
		virtual SceneNode* getNode() = 0;
};

//////////////////////////////////////////////////////////////////////////
// class GeoForm (from all the forms will inherit)
//////////////////////////////////////////////////////////////////////////
class GeoForm : public Geo {

	protected:
		//static double id = 0;
		ManualObject *manObj;
		SceneNode *node;
	
	public:
		GeoForm(SceneManager* mSceneMgr, const std::string& objName);
		virtual ~GeoForm();
		ManualObject* getObject();
		SceneNode* getNode();
};

//////////////////////////////////////////////////////////////////////////
// class CuboidForm (creates paralelipipides)
//////////////////////////////////////////////////////////////////////////
class CuboidForm : public GeoForm {
	
	private:
		const std::string& objName;
		const std::string& texName;
		Vector3 p1, p2;
		void Init(float x1, float y1, float z1, float x2, float y2, float z2);
	
	public:
		//default side size = 10, first default point = (-5,-5,-5), second default point = (5,5,5)
		CuboidForm(SceneManager* mSceneMgr, const std::string& objName, const std::string& texName, float x1 = -5, float y1 = -5, float z1 = -5, float x2 = 5, float y2 = 5, float z2 = 5);
		virtual ~CuboidForm();
		void Resize(float x1, float y1, float z1, float x2, float y2, float z2);
		void Scale(const float xScale, const float yScale, const float zScale);
};

//////////////////////////////////////////////////////////////////////////
// class SphereForm (creates spheres)
//////////////////////////////////////////////////////////////////////////
class SphereForm : public GeoForm {

	private:
		const std::string& objName;
		const std::string& texName;
		const float r;
		const int nRings, nSegments;
		const Vector3 center;
		
	public:
		//default number of rings and segments = 16
		SphereForm(SceneManager* mSceneMgr, const std::string& objName, const std::string& texName, const float r, float x_center, float y_center, float z_center, const int nRings = 16, const int nSegments = 16);
		virtual ~SphereForm();
		void Translate(const float x, const float y, const float z);
		void Scale(const float xScale, const float yScale, const float zScale);
};

//////////////////////////////////////////////////////////////////////////
// Class CylinderForm (creates cylinders)
//////////////////////////////////////////////////////////////////////////
class CylinderForm : public GeoForm {

	private:
		const std::string& objName;
		const std::string& texName;
		const float r, accuracy;

	public:
		CylinderForm(SceneManager* mSceneMgr,const std::string& objName, const std::string& texName, const float r, float x1, float y1, float z1, float x2, float y2, float z2, const float accuracy);
		virtual ~CylinderForm();
		void Translate(const float x, const float y, const float z);
		void Rotate(const float pitch, const float yaw, const float roll);
		void Scale(const float xScale, const float yScale, const float zScale);
};
