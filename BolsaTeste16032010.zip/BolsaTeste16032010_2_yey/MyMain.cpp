/*
 * MyMain.cpp
 *
 *  Created on: 2009/10/10
 *      Author: Jojoma
 */

#include "Geo.h"
#include <stdlib.h>
#include <list>
#include <Ogre.h>

#include "Ogre.h"
#include "OgreConfigFile.h"
#include "MyFrameListener.h"

#include <OIS/OIS.h>
//#include <CEGUI/CEGUI.h>
//#include <OgreCEGUIRenderer.h>

using namespace Ogre;

/** Base class which manages the standard startup of an Ogre application.
    Designed to be subclassed for specific examples if required.
*/
class ExampleApplication
{
public:
    /// Standard constructor
    ExampleApplication()
    {
        mFrameListener = 0;
        mRoot = 0;
		// Provide a nice cross platform solution for locating the configuration files
		// On windows files are searched for in the current working directory, on OS X however
		// you must provide the full path, the helper function macBundlePath does this for us.
		mResourcePath = "";
    }
    /// Standard destructor
    virtual ~ExampleApplication()
    {
        if (mFrameListener)
            delete mFrameListener;
        if (mRoot)
            delete mRoot;
    }

    /// Start the example
    virtual void go(void)
    {
        if (!setup())
            return;

        mRoot->startRendering();

        // clean up
        destroyScene();
    }

protected:
    Root *mRoot;
    Camera* mCamera;
    SceneManager* mSceneMgr;
    MyFrameListener* mFrameListener;
    RenderWindow* mWindow;
	Ogre::String mResourcePath;
	String pluginsPath;
	/*
    OIS::InputManager *mInputManager;
    CEGUI::OgreCEGUIRenderer *mRenderer;
    CEGUI::System *mSystem;
    */

    // These internal methods package up the stages in the startup process
    /** Sets up the application - returns false if the user chooses to abandon configuration. */
    virtual bool setup(void)
    {

		// only use plugins.cfg if not static
#ifndef OGRE_STATIC_LIB
		pluginsPath = mResourcePath + "plugins.cfg";
#endif

		createRoot();
        setupResources();

        bool carryOn = configure();
        if (!carryOn)
        	return false;

        //antes de criar uma cena, temos de ter 3 cenas basicas: um SceneManager, uma Camera e um Viewport para essa camera
        chooseSceneManager();
        createCamera();
        createViewports();

		// Create any resource listeners (for loading screens)
		createResourceListener();
		//initialize resources
		initializeResourceGroups();

		// Create the scene
        createScene();
        createFrameListener();

        return true;
    }

    virtual void createRoot()
    {
    	 mRoot = new Root(pluginsPath, mResourcePath + "ogre.cfg", mResourcePath + "Ogre.log");
    }

    /** Configures the application - returns false if the user chooses to abandon configuration. */
    virtual bool configure(void)
    {
        // Show the configuration dialog and initialise the system
        // You can skip this and use root.restoreConfig() to load configuration
        // settings if you were sure there are valid ones saved in ogre.cfg
        if(mRoot->showConfigDialog())
        {
            // If returned true, user clicked OK so initialise
            // Here we choose to let the system create a default rendering window by passing 'true'
            mWindow = mRoot->initialise(true, "Work in progress...");
            return true;
        }
        else
        {
            return false;
        }
    }

    virtual void chooseSceneManager(void)
    {
        // Create the SceneManager, in this case a generic one
        mSceneMgr = mRoot->createSceneManager(ST_GENERIC, "Default SceneManager");
    }

    virtual void createCamera(void)
    {
        // Create the camera
        mCamera = mSceneMgr->createCamera("PlayerCam");

       // mCamera->setPosition(Vector3(100,0,0));
        mCamera->setPosition(Vector3(400,200,300));
        // Look back along -Z
        mCamera->lookAt(Vector3(0,0,0));
        mCamera->setNearClipDistance(5);

        // ------------------------------
        // different camera settings
        // ------------------------------

        //cam 1
			//mCamera->setPosition(100,100,0);
        	//mCamera->lookAt(0,0,0);

        //cam 2
        	//mCamera->setPosition(0,0,100);
        	//mCamera->lookAt(0,0,0);

    }

    //usa o MyFrameListener (copia do ExampleFrameListener do Ogre), o sistema de Input ja esta todo definido la (OIS);
    //quaisquer frameListeners que tenhamos teem de ser adicionados a root (pex: mKeyboard->setEventCallback(mKeyListener);)
    virtual void createFrameListener(void)
    {
        mFrameListener = new MyFrameListener(mWindow, mCamera);
        mFrameListener->showDebugOverlay(true);
        mRoot->addFrameListener(mFrameListener);
    }

    virtual void createScene(void) = 0;    // pure virtual - this has to be overridden

    virtual void destroyScene(void){}    // Optional to override this

    virtual void createViewports(void)
    {
        // Create one viewport, entire window
        Viewport* vp = mWindow->addViewport(mCamera);
        vp->setBackgroundColour(ColourValue(0,0,0));

        // Alter the camera aspect ratio to match the viewport
        mCamera->setAspectRatio(
            Real(vp->getActualWidth()) / Real(vp->getActualHeight()));

        //para so cortar os objectos caso esteja o mais proximo possivel
        mCamera->setNearClipDistance(1);
    }

    /// Method which will define the source of resources (other than current folder)
    virtual void setupResources(void)
    {
        // Load resource paths from config file
        ConfigFile cf;
        cf.load(mResourcePath + "resources.cfg");

        // Go through all sections & settings in the file
        ConfigFile::SectionIterator seci = cf.getSectionIterator();

        String secName, typeName, archName;
        while (seci.hasMoreElements())
        {
            secName = seci.peekNextKey();
            ConfigFile::SettingsMultiMap *settings = seci.getNext();
            ConfigFile::SettingsMultiMap::iterator i;
            for (i = settings->begin(); i != settings->end(); ++i)
            {
                typeName = i->first;
                archName = i->second;
#if OGRE_PLATFORM == OGRE_PLATFORM_APPLE
                // OS X does not set the working directory relative to the app,
                // In order to make things portable on OS X we need to provide
                // the loading with it's own bundle path location
                ResourceGroupManager::getSingleton().addResourceLocation(
                    String(macBundlePath() + "/" + archName), typeName, secName);
#else
                ResourceGroupManager::getSingleton().addResourceLocation(
                    archName, typeName, secName);
#endif
            }
        }
    }

	/// Optional override method where you can create resource listeners (e.g. for loading screens)
	virtual void createResourceListener(void)
	{

	}

	/// Optional override method where you can perform resource group loading
	/// Must at least do ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
	virtual void loadResources(void)
	{
		// Initialise, parse scripts etc
		ResourceGroupManager::getSingleton().initialiseAllResourceGroups();

	}

	virtual void initializeResourceGroups(void)
	{
		//definir qual o numero de mipmaps que as texturas vao ter
		TextureManager::getSingleton().setDefaultNumMipmaps(5);
		//inicializar todos os resources que foram registados no defineResources()
		ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
	}

};


// ----------------------------------------------------------------------------
// Define the application object
// This is derived from ExampleApplication which is the class OGRE provides to
// make it easier to set up OGRE without rewriting the same code all the time.
// You can override extra methods of ExampleApplication if you want to further
// specialise the setup routine, otherwise the only mandatory override is the
// 'createScene' method which is where you set up your own personal scene.
// ----------------------------------------------------------------------------
class SampleApp : public ExampleApplication
{
public:
    // Basic constructor
    SampleApp()
    {}

protected:

    // Scene Setup
    // override the mandatory create scene method
    void createScene(void)
    {

    	// ------------------------------
    	// axis system
    	// ------------------------------

    	float axisThickness = 0.3;
    	createAxisSystem(mSceneMgr, axisThickness);

    	// ------------------------------
    	// let there be light!
    	// ------------------------------

//        Light* myLight = mSceneMgr->createLight("Light0");
//        myLight->setType(Light::LT_SPOTLIGHT);
//        myLight->setPosition(0,0,-400);
//        myLight->setDiffuseColour(1, 1, 1);
//        myLight->setSpecularColour(1, 1, 1);
        Light* myLight2 = mSceneMgr->createLight("Light2");
        myLight2->setType(Light::LT_POINT);
        myLight2->setPosition(1500, 500, 1500);
        myLight2->setDiffuseColour(1, 1, 1);
        myLight2->setSpecularColour(1, 1, 1);

		mSceneMgr->setAmbientLight(ColourValue(0.2, 0.2, 0.2));
		mSceneMgr->setShadowTechnique(SHADOWTYPE_STENCIL_ADDITIVE);


		// ------------------------------
		// criar o plano
		// ------------------------------

		Entity *ent;
		Plane plane(Vector3::UNIT_Y, -50);
		//registar o plano no MeshManager (que controla o uso das meshes carregadas no nosso programa)
		//a funcao createPlane recebe um Plane e cria uma mesh com os parametros dados
		MeshManager::getSingleton().createPlane("ground", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, plane, 1500,1500,20,20,true,1,20,20,Vector3::UNIT_Z);
		//so falta torna-lo uma entidade e...
		ent = mSceneMgr->createEntity("GroundEntity","ground");
		//...associa-lo a um sceneNode
		mSceneMgr->getRootSceneNode()->createChildSceneNode()->attachObject(ent);
		//definir o material que vai cobrir o plano
		ent->setMaterialName("Examples/RustySteel");
		//nos nao queremos que o plano lance sombra
		ent->setCastShadows(false);


		// ------------------------------
		// debug buddy =)
		// ------------------------------

		Entity *robot = mSceneMgr->createEntity( "Robot", "robot.mesh" );
		SceneNode *nodeRobot = mSceneMgr->getRootSceneNode()->createChildSceneNode("RobotNode");
		nodeRobot->attachObject(robot);
		nodeRobot->scale(0.5,0.5,0.5);
		//nodeRobot->translate(1500,500,1500);

//		Entity *bigrobot = mSceneMgr->createEntity( "Big_Robot", "robot.mesh" );
//		SceneNode *nodeBigRobot = mSceneMgr->getRootSceneNode()->createChildSceneNode("BigRobotNode");
//		nodeBigRobot->attachObject(bigrobot);
//		//nodeBigRobot->scale(5,5,5);
//		nodeBigRobot->translate(0,0,-50);

		// ------------------------------
		// variaveis
		// ------------------------------

		//escolher o tamanho do lado do cubo e a textura
		String texName3 = "Template/MyRed50";
		String texName4 = "Template/Blue50";
		String texName = "Examples/10PointBlock";
		String texTest = "Template/Test";

		String redSquare = "Examples/RedSquare";
		String greenSquare = "Examples/GreenSquare";
		String blueSquare = "Examples/BlueSquare";

		const double radius = 10, height = 20, accuracy = 20;
		int sideSize = 20;

		// ------------------------------
		// teste do professor (com esferas a partir de uma mesh)
		// ------------------------------

//		int x;
//		 char str[30];
//			for(x=1;x<1000;x=x+1) {
//				 itoa(x,str,10);
//				 sphere = mSceneMgr->createEntity(str, "sphere.mesh");
//				 sphere->setMaterialName("Template/Red");
//				 node2 = mSceneMgr->getRootSceneNode()->createChildSceneNode(str);
//				 node2->attachObject(sphere);
//				 node2->setPosition(Vector3(rand()/10, rand()/10,-rand()/10));
//			}

		// ------------------------------
		// testes com ManualObjects
		// ------------------------------

			// ------------------
			// cilindros
			// ------------------

	//		CylinderForm *cylinder;
	//		srand(time(NULL));
	//
	//		int x;
	//		char str[30];
	//		for(x = 1; x < 20; x = x + 1) {
	//			 itoa(x,str,10);
	//
	//			 float x1 = rand()%1000;
	//			 float y1 = rand()%1000;
	//			 float z1 = rand()%1000;
	//			 float x2 = rand()%1000;
	//			 float y2 = rand()%1000;
	//			 float z2 = rand()%1000;
	//
	//			 std::cout << "cilindro " << x << "\n";
	//			 std::cout << "x1 = " << x1 << " y1 = " << y1 << " z1 = " << z1 << "\n";
	//			 std::cout << "x2 = " << x2 << " y2 = " << y2 << " z2 = " << z2 << "\n";
	//
	//			 cylinder = new CylinderForm(mSceneMgr, str, redSquare, 5, x1, y1, z1, x2, y2, z2, accuracy);
	//			 SceneNode* node = cylinder->getNode();
	//			 //node->setPosition(Vector3(-rand()%500, rand()%50, -rand()%500));
	//		}

			CylinderForm *test = new CylinderForm(mSceneMgr, "one", texName, 2, 0, 50, 0, 0, 0, 50, accuracy);
			//CylinderForm *test2 = new CylinderForm(mSceneMgr, "two", redSquare, 2, 0, 0, 0, 0, 10, 0, accuracy);
	//
	//		SceneNode* node = test->getNode();
	//		node->setPosition(Vector3(0, 0, 200));
	//		SceneNode* node2 = test2->getNode();
	//		node2->setPosition(Vector3(0, 0, 100));


			// ------------------
			// cubos
			// ------------------

	//		CuboidForm *cube;
	//		srand(time(NULL));
	//
	//		int x;
	//		char str[30];
	//		for(x = 1; x < 20; x = x + 1) {
	//			 itoa(x,str,10);
	//			 cube = new CuboidForm(mSceneMgr, str, texName2, rand()%50, rand()%50, rand()%50, rand()%50, rand()%50, rand()%50);
	//			 SceneNode* node = cube->getNode();
	//			 node->setPosition(Vector3(-rand()%500, rand()%50, -rand()%500));
	//		}


	}

    //metodo para criar o sistema de eixos ortonormado Oxyz (RGB <=> XYZ; R=X, G=Y, B=Z)
    void createAxisSystem(SceneManager* mSceneMgr, float thickness) {

    	String redSquare = "Examples/RedSquare";
    	String greenSquare = "Examples/GreenSquare";
    	String blueSquare = "Examples/BlueSquare";

    	float accuracy = 16;

    	new CylinderForm(mSceneMgr, "xAxis", redSquare, thickness, 0, 0, 0, 50, 0, 0, accuracy);
    	new CylinderForm(mSceneMgr, "yAxis", greenSquare, thickness, 0, 0, 0, 0, 50, 0, accuracy);
    	new CylinderForm(mSceneMgr, "zAxis", blueSquare, thickness, 0, 0, 0, 0, 0, 50, accuracy);

    }
};


// ----------------------------------------------------------------------------
// Main function, just boots the application object
// ----------------------------------------------------------------------------
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#define WIN32_LEAN_AND_MEAN
#include "windows.h"
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR strCmdLine, INT )
#else
int main(int argc, char **argv)
#endif
{
    // Create application object
    SampleApp app;

    try
    {
        app.go();
    }
    catch( Exception& e )
    {
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
        MessageBox( NULL, e.getFullDescription().c_str(), "An exception has occured!", MB_OK | MB_ICONERROR | MB_TASKMODAL);
#else

        std::cerr << "An exception has occured: " << e.getFullDescription();
#endif
    }

    return 0;
}
