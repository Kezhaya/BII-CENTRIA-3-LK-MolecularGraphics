/*
 * Geo.cpp
 *
 *  Created on: 2009/10/10
 *      Author: Jojoma
 */

#include <stdlib.h>
#include <list>
#include <Ogre.h>
#include "Geo.h"

using namespace Ogre;

//useful functions
Matrix3 RotateMatrix_x(double angle) {

	return Matrix3(1,       0,        0,
			       0,  cos(angle), -sin(angle),
			       0,  sin(angle),  cos(angle));
}

Matrix3 RotateMatrix_y(double angle) {

	return Matrix3( cos(angle),    0,   sin(angle),
						0,         1,       0,
			       -sin(angle),    0,   cos(angle));
}

Matrix3 RotateMatrix_z(double angle) {

	return Matrix3(cos(angle), -sin(angle),  0,
		           sin(angle),  cos(angle),  0,
		               0,           0,       1);
}

//class GeoForm
GeoForm::GeoForm(SceneManager* mSceneMgr, const std::string& objName) {

	manObj = new ManualObject(objName);
	node = mSceneMgr->getRootSceneNode()->createChildSceneNode(objName);
}
GeoForm::~GeoForm() { delete manObj; delete node; }
ManualObject* GeoForm::getObject() { return manObj; }
SceneNode* GeoForm::getNode() { return node; }

//class Cuboid
//(x1,y1,z1) -> first point
//(x2,y2,z2) -> second point
//the cuboid's edges are all parallel to the world axis system (oxyz);
//for simplification matters, lets assume that all the values are in the octant where x y and z are positive;
CuboidForm::CuboidForm(SceneManager* mSceneMgr, const std::string& objName, const std::string& texName,
					   float x1, float y1, float z1, float x2, float y2, float z2) :
	GeoForm(mSceneMgr, objName), objName(objName), texName(texName)
{
	Init(x1, y1, z1, x2, y2, z2);
}

CuboidForm::~CuboidForm() {}

void CuboidForm::Init(float x1, float y1, float z1, float x2, float y2, float z2) {

	float z_front, z_back, y_top, y_bottom, x_left, x_right;

		//by principle the equality situation wont happen,
		//but it is there just to make sure the variables are all initialized.
		//the y axis points up
		if(y1 >= y2)
			{ y_top = y1; y_bottom = y2; }
		else
			{ y_top = y2; y_bottom = y1; }

		//the x axis points right
		if(x1 >= x2)
			{ x_left = x2; x_right = x1; }
		else
			{ x_left = x1; x_right = x2; }

		//the z axis points towards from the screen towards the user
		if(z1 >= z2)
			{ z_front = z1; z_back = z2; }
		else
			{ z_front = z2; z_back = z1; }

		// fill the manual object with vertex, texcoord, normal...
		//3 vertices per triangle
		manObj->begin(texName,RenderOperation::OT_TRIANGLE_LIST);

			//bottom face
				//first triangle: 0->1->2
				manObj->position(x_right,y_bottom,z_back);		manObj->textureCoord(1,1);		manObj->normal(0, -1, 0); 	//0
				manObj->position(x_right,y_bottom,z_front); 	manObj->textureCoord(1,0);		manObj->normal(0, -1, 0); 	//1
				manObj->position(x_left,y_bottom,z_front); 		manObj->textureCoord(0,0);		manObj->normal(0, -1, 0);	//2

				//second triangle: 0->2->3
				manObj->position(x_right,y_bottom,z_back);		manObj->textureCoord(1,1);		manObj->normal(0, -1, 0); 	//0
				manObj->position(x_left,y_bottom,z_front); 		manObj->textureCoord(0,0);		manObj->normal(0, -1, 0);	//2
				manObj->position(x_left,y_bottom,z_back); 		manObj->textureCoord(0,1); 		manObj->normal(0, -1, 0); 	//3

			//top face
				//first triangle: 4->5->7
				manObj->position(x_right,y_top,z_back); 		manObj->textureCoord(1,0);   	manObj->normal(0, 1, 0);	//4
				manObj->position(x_left,y_top,z_back); 			manObj->textureCoord(0,0); 		manObj->normal(0, 1, 0);	//5
				manObj->position(x_right,y_top,z_front);		manObj->textureCoord(1,1);   	manObj->normal(0, 1, 0);	//7

				//second triangle: 5->6->7
				manObj->position(x_left,y_top,z_back); 			manObj->textureCoord(0,0); 		manObj->normal(0, 1, 0);	//5
				manObj->position(x_left,y_top,z_front); 		manObj->textureCoord(0,1); 		manObj->normal(0, 1, 0);	//6
				manObj->position(x_right,y_top,z_front);		manObj->textureCoord(1,1);   	manObj->normal(0, 1, 0);	//7

			//right face
				//first triangle: 8->9->11
				manObj->position(x_right,y_bottom,z_back);		manObj->textureCoord(1,0);		manObj->normal(1, 0, 0); 	//8
				manObj->position(x_right,y_top,z_back); 		manObj->textureCoord(0,0);		manObj->normal(1, 0, 0); 	//9
				manObj->position(x_right,y_bottom,z_front); 	manObj->textureCoord(1,1);		manObj->normal(1, 0, 0); 	//11

				//second triangle: 9->10->11
				manObj->position(x_right,y_top,z_back); 		manObj->textureCoord(0,0);		manObj->normal(1, 0, 0); 	//9
				manObj->position(x_right,y_top,z_front); 		manObj->textureCoord(0,1); 		manObj->normal(1, 0, 0); 	//10
				manObj->position(x_right,y_bottom,z_front); 	manObj->textureCoord(1,1);		manObj->normal(1, 0, 0); 	//11

			//front face
				//first triangle: 12->13->15
				manObj->position(x_right,y_bottom,z_front); 	manObj->textureCoord(1,0); 		manObj->normal(0, 0, 1); 	//12
				manObj->position(x_right,y_top,z_front); 		manObj->textureCoord(0,0); 		manObj->normal(0, 0, 1); 	//13
				manObj->position(x_left,y_bottom,z_front); 		manObj->textureCoord(1,1); 		manObj->normal(0, 0, 1); 	//15

				//second triangle: 13->14->15
				manObj->position(x_right,y_top,z_front); 		manObj->textureCoord(0,0); 		manObj->normal(0, 0, 1); 	//13
				manObj->position(x_left,y_top,z_front); 		manObj->textureCoord(0,1); 		manObj->normal(0, 0, 1); 	//14
				manObj->position(x_left,y_bottom,z_front); 		manObj->textureCoord(1,1); 		manObj->normal(0, 0, 1); 	//15

			//left face
				//first triangle: 16->17->18
				manObj->position(x_left,y_bottom,z_front); 		manObj->textureCoord(1,0);		manObj->normal(-1, 0, 0);	//16
				manObj->position(x_left,y_top,z_front);			manObj->textureCoord(0,0);		manObj->normal(-1, 0, 0);	//17
				manObj->position(x_left,y_top,z_back); 			manObj->textureCoord(0,1);		manObj->normal(-1, 0, 0); 	//18

				//second triangle: 16->18->19
				manObj->position(x_left,y_bottom,z_front); 		manObj->textureCoord(1,0);		manObj->normal(-1, 0, 0);	//16
				manObj->position(x_left,y_top,z_back); 			manObj->textureCoord(0,1);		manObj->normal(-1, 0, 0); 	//18
				manObj->position(x_left,y_bottom,z_back); 		manObj->textureCoord(1,1); 		manObj->normal(-1, 0, 0); 	//19

			//back face
				//first triangle: 20->21->23
				manObj->position(x_right,y_top,z_back); 		manObj->textureCoord(0,1); 		manObj->normal(0, 0, -1);	//20
				manObj->position(x_right,y_bottom,z_back); 		manObj->textureCoord(1,1);		manObj->normal(0, 0, -1);	//21
				manObj->position(x_left,y_top,z_back); 			manObj->textureCoord(0,0);		manObj->normal(0, 0, -1);	//23

				//second triangle: 21->22->23
				manObj->position(x_right,y_bottom,z_back); 		manObj->textureCoord(1,1);		manObj->normal(0, 0, -1);	//21
				manObj->position(x_left,y_bottom,z_back);		manObj->textureCoord(1,0);		manObj->normal(0, 0, -1);	//22
				manObj->position(x_left,y_top,z_back); 			manObj->textureCoord(0,0);		manObj->normal(0, 0, -1);	//23

		manObj->end();

		//coloring the edges (it works)

//		// Front face
//		manObj->begin("Template/White",RenderOperation::OT_LINE_STRIP);
//
//			manObj->position(x_right,y_top,z_front);		//B
//			manObj->position(x_right,y_bottom,z_front); 	//C
//			manObj->position(x_left,y_bottom,z_front); 		//D
//			manObj->position(x_left,y_top,z_front); 		//A
//			manObj->position(x_right,y_top,z_front);		//B
//
//		manObj->end(); // end of a LINE_STRIP
//
//		// Left face
//		manObj->begin("Template/White",RenderOperation::OT_LINE_STRIP);
//
//			manObj->position(x_left,y_top,z_front); 		//A
//			manObj->position(x_left,y_top,z_back); 			//E
//			manObj->position(x_left,y_bottom,z_back); 		//H
//			manObj->position(x_left,y_bottom,z_front); 		//D
//
//		manObj->end(); // end of a LINE_STRIP
//
//		// Back face
//		manObj->begin("Template/White",RenderOperation::OT_LINE_STRIP);
//
//			manObj->position(x_left,y_top,z_back); 			//E
//			manObj->position(x_right,y_top,z_back); 		//F
//			manObj->position(x_right,y_bottom,z_back); 		//G
//			manObj->position(x_left,y_bottom,z_back); 		//H
//
//		manObj->end(); // end of a LINE_STRIP
//
//		// Right face (LINE_LIST -> 2 vertices por linha)
//		manObj->begin("Template/White",RenderOperation::OT_LINE_LIST);
//
//			manObj->position(x_right,y_top,z_front);		//B
//			manObj->position(x_right,y_top,z_back); 		//F
//			manObj->position(x_right,y_bottom,z_front); 	//C
//			manObj->position(x_right,y_bottom,z_back); 		//G
//
//		manObj->end(); // end of a LINE_LIST
//
		node->attachObject(manObj);
}

//cuboid's center: (sideSize/2, sideSize/2, -sideSize/2)
void CuboidForm::Scale(const float xScale, const float yScale, const float zScale) { }	//TODO

void CuboidForm::Resize(float x1, float y1, float z1, float x2, float y2, float z2) {

	Init(x1, y1, z1, x2, y2, z2);
}

//class Sphere
SphereForm::SphereForm(SceneManager* mSceneMgr, const std::string& objName, const std::string& texName,
					   const float r, float x_center, float y_center, float z_center, const int nRings,
					   const int nSegments) :
	GeoForm(mSceneMgr, objName), objName(objName), texName(texName), r(r), nRings(nRings), nSegments(nSegments)
{
	manObj->setCastShadows(true);

    manObj->begin(texName, RenderOperation::OT_TRIANGLE_LIST);

    	float fDeltaRingAngle = (Math::PI / nRings);
    	float fDeltaSegAngle = (2 * Math::PI / nSegments);
    	unsigned short wVerticeIndex = 0 ;

    	// Generate the group of rings for the sphere
    	for( int ring = 0; ring <= nRings; ring++ ) {
    		float r0 = r * sinf (ring * fDeltaRingAngle);
    		float y0 = r * cosf (ring * fDeltaRingAngle);

    		// Generate the group of segments for the current ring
    		for(int seg = 0; seg <= nSegments; seg++) {

    			float x0 = r0 * sinf(seg * fDeltaSegAngle);
    			float z0 = r0 * cosf(seg * fDeltaSegAngle);

    			// Add one vertex to the strip which makes up the sphere
    			manObj->position( x0 + x_center, y0 + y_center, z0 + z_center);
    			manObj->normal(Vector3(x0, y0, z0).normalisedCopy());
    			manObj->textureCoord((float) seg / (float) nSegments, (float) ring / (float) nRings);

    			if (ring != nRings) {
    				// each vertex (except the last) has six indicies pointing to it
    				manObj->index(wVerticeIndex + nSegments + 1);
    				manObj->index(wVerticeIndex);
    				manObj->index(wVerticeIndex + nSegments);
    				manObj->index(wVerticeIndex + nSegments + 1);
    				manObj->index(wVerticeIndex + 1);
    				manObj->index(wVerticeIndex);
    				wVerticeIndex ++;
    			}
    		} // end for seg
    	} // end for ring

    manObj->end();


/*
    MeshPtr mesh = manObj->convertToMesh(objName);

    mesh->_setBounds( AxisAlignedBox( Vector3(-r, -r, -r), Vector3(r, r, r) ), false );
    mesh->_setBoundingSphereRadius(r);

    unsigned short src, dest;
    if (!mesh->suggestTangentVectorBuildParams(VES_TANGENT, src, dest))
    {
       	mesh->buildTangentVectors(VES_TANGENT, src, dest);
    }*/

    node->attachObject(manObj);
}

SphereForm::~SphereForm() {}

//o centro da esfera esta' inicialmente no ponto (0,0,0)
void SphereForm::Translate(const float x, const float y, const float z) {  }

void SphereForm::Scale(const float xScale, const float yScale, const float zScale) { }

//////////////////////////////////////////////////////////////////////////
// Class CylinderForm (creates cylinders)
//////////////////////////////////////////////////////////////////////////
//NOTE: accuracy can NEVER be 0!!! should be >= 1
CylinderForm::CylinderForm(SceneManager* mSceneMgr,const std::string& objName, const std::string& texName,
						   const float r, float x1, float y1, float z1, float x2, float y2, float z2,
						   const float accuracy) :
	GeoForm(mSceneMgr, objName), objName(objName), texName(texName), r(r), accuracy(accuracy)
{
	float z_front, z_back, y_top, y_bottom, x_left, x_right;
	
	//by principle the equality situation wont happen,
	//but it is there just to make sure the variables are all initialized.
	//the y axis points up
	if(y1 >= y2)
		{ y_top = y1; y_bottom = y2; }
	else
		{ y_top = y2; y_bottom = y1; }
	
	//the x axis points right
	if(x1 >= x2)
		{ x_left = x2; x_right = x1; }
	else
		{ x_left = x1; x_right = x2; }
	
	//the z axis points towards from the screen towards the user
	if(z1 >= z2)
		{ z_front = z1; z_back = z2; }
	else
		{ z_front = z2; z_back = z1; }
	
	float delta_x = x_right - x_left;
	float delta_y = y_top - y_bottom;
	float delta_z = z_front - z_back;
	
	//the height of the cylinder is the module of the vector that unites the both bases
	float h = sqrt(pow(delta_x, 2) + pow(delta_y, 2) + pow(delta_z, 2));

	std::cout << "h =" << h << " delta x = " << delta_x << " delta y = " << delta_y << " delta z = " << delta_z << "\n";

	float top_height = h/2, bottom_height = -h/2;

	///////////////////////////////////////////////
	// rotations
	///////////////////////////////////////////////

	//first axis (the one that unites the two bases' centers)
	Vector3 axis1 = Vector3(x2, y2, z2) - Vector3(x1, y1, z1);
	axis1.normalise();

	std::cout << "axis1: " << " x = " << axis1.x << " y = " << axis1.y << " z = " << axis1.z << "\n";

	//second axis (one axis perpendicular to the first)
	Vector3 axis2 = axis1.perpendicular();
	axis2.normalise();
	
	std::cout << "axis2: " << " x = " << axis2.x << " y = " << axis2.y << " z = " << axis2.z << "\n";

	//third axis (one orthogonal to the the other two)
	Vector3 axis3 = axis1.crossProduct(axis2);
	axis3.normalise();

	std::cout << "axis3: " << " x = " << axis3.x << " y = " << axis3.y << " z = " << axis3.z << "\n";

	//calculate the final rotation matrix
	//the first column (axis3) is the new x axis
	//the second column (axis1) is the new y axis
	//the third colums (axis2) is the new z axis
	//the resultant quarternion (qua) from that rotation matrix will be need
	Matrix3 local2world = Matrix3(axis3.x, axis1.x, axis2.x,
								  axis3.y, axis1.y, axis2.y,
								  axis3.z, axis1.z, axis2.z);

	Quaternion qua = Quaternion(local2world);

	///////////////////////////////////////////////
	// construction
	///////////////////////////////////////////////

	// accuracy is the count of points (and lines).
    // Higher values make the circle smoother, but may slowdown the performance.
    // The performance also is related to the count of circles.
	
	std::list<Vector3> base1, base2, reverse1;
	std::list<Vector3>::iterator iter1, iter2;
	std::list<Vector3>::reverse_iterator rev2;

    //calculate the points for the bases (bottom plane height = 0; top plane height = h)
    for(double theta = 0; theta <= 2 * Math::PI; theta += Math::PI / accuracy) {
    	Vector3 *temp1 = new Vector3(r * cos(theta), bottom_height, r * sin(theta));
    	Vector3 *temp2 = new Vector3(r * cos(theta), top_height, r * sin(theta));
		base1.push_back(*temp1);
		base2.push_back(*temp2);
    }
    //close the bases
    base1.push_back(Vector3(r, bottom_height, 0));
    base1.push_back(Vector3(r, top_height, 0));
	
    ///////////////////////////////
    // bottom base (the first)
    ///////////////////////////////

    //calculate the normal vector for the bottom base only once
    //(its the same for every point)
    Vector3 bottom_normal = Vector3::NEGATIVE_UNIT_Y;

	manObj->begin(texName, RenderOperation::OT_TRIANGLE_FAN);

		iter1 = base1.begin();
		while( iter1 != base1.end() ) {
			std::list<Vector3>::iterator head = iter1;
			++iter1;
			manObj->position(*head);
			manObj->normal(bottom_normal);
		}

	manObj->end();


	///////////////////////////////
	// top base (the second)
	///////////////////////////////

	//calculate the normal vector for the top base only once
	//(its the same for every point)
	Vector3 top_normal = Vector3::UNIT_Y;

	//must be iterated in reverse order,
	//so the normals of each triangle are siding up
	manObj->begin(texName, RenderOperation::OT_TRIANGLE_FAN);

		manObj->position(Vector3(0, top_height, 0));
		manObj->normal(top_normal);

		std::list<Vector3>::reverse_iterator head;
		rev2 = base2.rbegin();
		while( rev2 != base2.rend() ) {
			head = rev2;
			++rev2;
			manObj->position(*head);
			manObj->normal(top_normal);
		}
		rev2 = base2.rbegin();
		head = rev2;
		++rev2;
		manObj->position(*head);
		manObj->normal(top_normal);

	manObj->end();


	///////////////////////////////
	// side part
	///////////////////////////////

	manObj->begin(texName, RenderOperation::OT_TRIANGLE_STRIP);

		iter1 = base1.begin();
		iter2 = base2.begin();

		int i = 0;

		Vector3 center_top = Vector3(0, top_height, 0);
		Vector3 center_bottom = Vector3(0, bottom_height, 0);

		//a segunda condicao esta aqui porque por erros de arredondamento (va-se la saber porque)
		//quando ele fechava as bases no ultimo ponto, a coordenada do z passava-se e ia pro infinito;
		//logo, decidi impedi-lo de o fazer e adicionar o ultimo ponto a mao (fora do ciclo while)
		while( iter1 != base1.end() && i < accuracy * 2) {

			std::list<Vector3>::iterator head1 = iter1;
			std::list<Vector3>::iterator head2 = iter2;
			++iter1; ++iter2;
			//std::cout << "ponto " << i << " bottom : x=" << head1->x << " y=" << head1->y << " z=" << head1->z << "\n";
			//std::cout << "ponto " << i << " top :    x=" << head2->x << " y=" << head2->y << " z=" << head2->z << "\n";
			i++;

			manObj->position(*head1);
			Vector3 temp1 = center_bottom - *head1;
			manObj->normal(-temp1);

			manObj->position(*head2);
			Vector3 temp2 = center_top - *head2;
			manObj->normal(-temp2);
		}

		manObj->position(Vector3(r, bottom_height, 0));
		manObj->position(Vector3(r, top_height, 0));

	manObj->end();

	node->attachObject(manObj);	

	node->rotate(qua, SceneNode::TS_LOCAL);

    //translate para o midpoint da recta entre os centros das bases
	node->translate((x1 + x2)/2, (y1 + y2)/2, (z1 + z2)/2);
}

CylinderForm::~CylinderForm() {}

void CylinderForm::Translate(const float x, const float y, const float z)  { }
void CylinderForm::Rotate(const float pitch, const float yaw, const float roll)  { }
void CylinderForm::Scale(const float xScale, const float yScale, const float zScale)  { }
